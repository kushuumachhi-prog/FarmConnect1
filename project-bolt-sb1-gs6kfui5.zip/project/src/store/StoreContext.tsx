import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Product } from "@/data/products";
import { PRODUCTS as INITIAL_PRODUCTS } from "@/data/products";
import type { Farmer } from "@/data/farmers";
import { FARMERS as INITIAL_FARMERS } from "@/data/farmers";

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  subtotal: number;
  deliveryCharge: number;
  total: number;
  status: "Order Confirmed" | "Picked Up" | "At Collection Center" | "In Transit" | "Out for Delivery" | "Delivered";
  paymentStatus: "Pending" | "Processing" | "Successful" | "Failed";
  paymentMethod: string;
  buyerName: string;
  buyerAddress: string;
  buyerPhone: string;
  orderDate: string;
  estimatedDelivery: string;
}

export interface WishlistItem {
  productId: string;
}

interface StoreContextType {
  products: Product[];
  farmers: Farmer[];
  cart: CartItem[];
  wishlist: string[];
  orders: Order[];
  location: string;
  setLocation: (loc: string) => void;
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;
  addProduct: (product: Omit<Product, "id">) => Product;
  addFarmer: (farmer: Omit<Farmer, "id">) => Farmer;
  placeOrder: (order: Omit<Order, "id" | "orderDate">) => Order;
  getFarmerById: (id: string) => Farmer | undefined;
  getProductById: (id: string) => Product | undefined;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const STORAGE_KEYS = {
  cart: "farmconnect_cart",
  wishlist: "farmconnect_wishlist",
  orders: "farmconnect_orders",
  products: "farmconnect_products",
  farmers: "farmconnect_farmers",
  location: "farmconnect_location",
};

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function saveToStorage<T>(key: string, value: T) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // ignore
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>(() =>
    loadFromStorage(STORAGE_KEYS.products, INITIAL_PRODUCTS)
  );
  const [farmers, setFarmers] = useState<Farmer[]>(() =>
    loadFromStorage(STORAGE_KEYS.farmers, INITIAL_FARMERS)
  );
  const [cart, setCart] = useState<CartItem[]>(() =>
    loadFromStorage(STORAGE_KEYS.cart, [])
  );
  const [wishlist, setWishlist] = useState<string[]>(() =>
    loadFromStorage(STORAGE_KEYS.wishlist, [])
  );
  const [orders, setOrders] = useState<Order[]>(() =>
    loadFromStorage(STORAGE_KEYS.orders, [])
  );
  const [location, setLocationState] = useState<string>(() =>
    loadFromStorage(STORAGE_KEYS.location, "All India")
  );

  useEffect(() => saveToStorage(STORAGE_KEYS.products, products), [products]);
  useEffect(() => saveToStorage(STORAGE_KEYS.farmers, farmers), [farmers]);
  useEffect(() => saveToStorage(STORAGE_KEYS.cart, cart), [cart]);
  useEffect(() => saveToStorage(STORAGE_KEYS.wishlist, wishlist), [wishlist]);
  useEffect(() => saveToStorage(STORAGE_KEYS.orders, orders), [orders]);
  useEffect(() => saveToStorage(STORAGE_KEYS.location, location), [location]);

  const setLocation = (loc: string) => setLocationState(loc);

  const addToCart = (product: Product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId
          ? {
              ...item,
              quantity: Math.min(quantity, item.product.availableQty),
            }
          : item
      )
    );
  };

  const clearCart = () => setCart([]);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce(
    (sum, item) => sum + item.product.pricePerUnit * item.quantity,
    0
  );

  const toggleWishlist = (productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  const isWishlisted = (productId: string) => wishlist.includes(productId);

  const addProduct = (product: Omit<Product, "id">): Product => {
    const id = `p${Date.now()}`;
    const newProduct = { ...product, id };
    setProducts((prev) => [newProduct, ...prev]);
    return newProduct;
  };

  const addFarmer = (farmer: Omit<Farmer, "id">): Farmer => {
    const id = `f${Date.now()}`;
    const newFarmer = { ...farmer, id };
    setFarmers((prev) => [newFarmer, ...prev]);
    return newFarmer;
  };

  const placeOrder = (order: Omit<Order, "id" | "orderDate">): Order => {
    const id = `ORD${Date.now()}`;
    const orderDate = new Date().toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });
    const newOrder: Order = { ...order, id, orderDate };
    setOrders((prev) => [newOrder, ...prev]);
    clearCart();
    return newOrder;
  };

  const getFarmerById = (id: string) => farmers.find((f) => f.id === id);
  const getProductById = (id: string) => products.find((p) => p.id === id);

  return (
    <StoreContext.Provider
      value={{
        products,
        farmers,
        cart,
        wishlist,
        orders,
        location,
        setLocation,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartCount,
        cartSubtotal,
        toggleWishlist,
        isWishlisted,
        addProduct,
        addFarmer,
        placeOrder,
        getFarmerById,
        getProductById,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
