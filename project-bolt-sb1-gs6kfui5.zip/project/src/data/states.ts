export interface StateInfo {
  name: string;
  cities: string[];
}

export const INDIAN_STATES: StateInfo[] = [
  { name: "Andhra Pradesh", cities: ["Visakhapatnam", "Vijayawada", "Guntur", "Tirupati", "Kakinada"] },
  { name: "Arunachal Pradesh", cities: ["Itanagar", "Naharlagun", "Tawang", "Pasighat"] },
  { name: "Assam", cities: ["Guwahati", "Dibrugarh", "Silchar", "Jorhat", "Tezpur"] },
  { name: "Bihar", cities: ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur", "Darbhanga"] },
  { name: "Chhattisgarh", cities: ["Raipur", "Bhilai", "Bilaspur", "Korba", "Durg"] },
  { name: "Goa", cities: ["Panaji", "Margao", "Vasco da Gama", "Mapusa"] },
  { name: "Gujarat", cities: ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Junagadh"] },
  { name: "Haryana", cities: ["Gurugram", "Faridabad", "Panipat", "Ambala", "Karnal", "Hisar"] },
  { name: "Himachal Pradesh", cities: ["Shimla", "Manali", "Dharamshala", "Solan", "Kullu"] },
  { name: "Jharkhand", cities: ["Ranchi", "Jamshedpur", "Dhanbad", "Bokaro", "Hazaribagh"] },
  { name: "Karnataka", cities: ["Bengaluru", "Mysuru", "Hubli", "Mangaluru", "Belagavi", "Kalaburagi"] },
  { name: "Kerala", cities: ["Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur", "Kollam"] },
  { name: "Madhya Pradesh", cities: ["Bhopal", "Indore", "Jabalpur", "Gwalior", "Ujjain", "Sagar"] },
  { name: "Maharashtra", cities: ["Mumbai", "Pune", "Nashik", "Nagpur", "Aurangabad", "Nashik", "Kolhapur", "Ratnagiri"] },
  { name: "Manipur", cities: ["Imphal", "Thoubal", "Bishnupur", "Ukhrul"] },
  { name: "Meghalaya", cities: ["Shillong", "Tura", "Jowai", "Nongstoin"] },
  { name: "Mizoram", cities: ["Aizawl", "Lunglei", "Champhai", "Serchhip"] },
  { name: "Nagaland", cities: ["Kohima", "Dimapur", "Mokokchung", "Tuensang"] },
  { name: "Odisha", cities: ["Bhubaneswar", "Cuttack", "Rourkela", "Sambalpur", "Puri", "Berhampur"] },
  { name: "Punjab", cities: ["Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bathinda", "Mohali"] },
  { name: "Rajasthan", cities: ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Ajmer", "Bikaner", "Sikar"] },
  { name: "Sikkim", cities: ["Gangtok", "Namchi", "Geyzing", "Mangan"] },
  { name: "Tamil Nadu", cities: ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Erode", "Thanjavur"] },
  { name: "Telangana", cities: ["Hyderabad", "Warangal", "Nizamabad", "Karimnagar", "Khammam"] },
  { name: "Tripura", cities: ["Agartala", "Dharmanagar", "Udaipur", "Kailasahar"] },
  { name: "Uttar Pradesh", cities: ["Lucknow", "Kanpur", "Agra", "Varanasi", "Meerut", "Allahabad", "Gorakhpur", "Bareilly"] },
  { name: "Uttarakhand", cities: ["Dehradun", "Haridwar", "Rishikesh", "Nainital", "Haldwani", "Roorkee"] },
  { name: "West Bengal", cities: ["Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri", "Darjeeling"] },
  { name: "Andaman and Nicobar Islands", cities: ["Port Blair", "Car Nicobar", "Havelock Island"] },
  { name: "Chandigarh", cities: ["Chandigarh"] },
  { name: "Dadra and Nagar Haveli and Daman and Diu", cities: ["Daman", "Diu", "Silvassa"] },
  { name: "Delhi", cities: ["New Delhi", "Dwarka", "Rohini", "Saket", "Najafgarh"] },
  { name: "Jammu and Kashmir", cities: ["Srinagar", "Jammu", "Anantnag", "Baramulla", "Udhampur"] },
  { name: "Ladakh", cities: ["Leh", "Kargil"] },
  { name: "Lakshadweep", cities: ["Kavaratti", "Agatti", "Minicoy"] },
  { name: "Puducherry", cities: ["Puducherry", "Karaikal", "Mahe", "Yanam"] },
];

export const ALL_INDIA = "All India";

export function getStateNames(): string[] {
  return [ALL_INDIA, ...INDIAN_STATES.map((s) => s.name)];
}

export function getCitiesForState(stateName: string): string[] {
  if (stateName === ALL_INDIA) return [];
  const s = INDIAN_STATES.find((s) => s.name === stateName);
  return s ? s.cities : [];
}
