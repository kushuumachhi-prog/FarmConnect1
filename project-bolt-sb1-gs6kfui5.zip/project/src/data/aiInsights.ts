export interface DemandForecast {
  product: string;
  expectedDemand: number;
  availableSupply: number;
  unit: "kg" | "tonne";
  demandStatus: "High" | "Moderate" | "Low";
  recommendedPrice: number;
  currentPrice: number;
  trend: "up" | "down" | "stable";
}

export const DEMAND_FORECASTS: DemandForecast[] = [
  { product: "Tomato", expectedDemand: 420, availableSupply: 300, unit: "kg", demandStatus: "High", recommendedPrice: 42, currentPrice: 40, trend: "up" },
  { product: "Onion", expectedDemand: 600, availableSupply: 800, unit: "kg", demandStatus: "Moderate", recommendedPrice: 30, currentPrice: 32, trend: "down" },
  { product: "Potato", expectedDemand: 500, availableSupply: 450, unit: "kg", demandStatus: "High", recommendedPrice: 30, currentPrice: 28, trend: "up" },
  { product: "Basmati Rice", expectedDemand: 2500, availableSupply: 2000, unit: "kg", demandStatus: "High", recommendedPrice: 90, currentPrice: 85, trend: "up" },
  { product: "Red Chilli", expectedDemand: 350, availableSupply: 300, unit: "kg", demandStatus: "High", recommendedPrice: 190, currentPrice: 180, trend: "up" },
  { product: "Mango", expectedDemand: 500, availableSupply: 400, unit: "kg", demandStatus: "High", recommendedPrice: 75, currentPrice: 70, trend: "up" },
  { product: "Wheat", expectedDemand: 2000, availableSupply: 1500, unit: "kg", demandStatus: "High", recommendedPrice: 38, currentPrice: 35, trend: "up" },
  { product: "Chickpeas", expectedDemand: 600, availableSupply: 700, unit: "kg", demandStatus: "Moderate", recommendedPrice: 72, currentPrice: 75, trend: "down" },
  { product: "Turmeric", expectedDemand: 300, availableSupply: 350, unit: "kg", demandStatus: "Moderate", recommendedPrice: 115, currentPrice: 120, trend: "stable" },
  { product: "Banana", expectedDemand: 550, availableSupply: 600, unit: "kg", demandStatus: "Moderate", recommendedPrice: 43, currentPrice: 45, trend: "stable" },
  { product: "Cumin", expectedDemand: 200, availableSupply: 250, unit: "kg", demandStatus: "Moderate", recommendedPrice: 210, currentPrice: 220, trend: "down" },
  { product: "Cardamom", expectedDemand: 180, availableSupply: 150, unit: "kg", demandStatus: "High", recommendedPrice: 880, currentPrice: 850, trend: "up" },
];

export const DEMAND_TREND_DATA = [
  { month: "Apr", demand: 320, supply: 280 },
  { month: "May", demand: 350, supply: 300 },
  { month: "Jun", demand: 410, supply: 340 },
  { month: "Jul", demand: 380, supply: 360 },
  { month: "Aug", demand: 450, supply: 390 },
  { month: "Sep", demand: 420, supply: 350 },
];

export const PRICE_TREND_DATA = [
  { month: "Apr", tomato: 35, onion: 28, potato: 25 },
  { month: "May", tomato: 38, onion: 30, potato: 26 },
  { month: "Jun", tomato: 42, onion: 35, potato: 28 },
  { month: "Jul", tomato: 45, onion: 38, potato: 30 },
  { month: "Aug", tomato: 42, onion: 34, potato: 28 },
  { month: "Sep", tomato: 40, onion: 32, potato: 28 },
];

export const SEASONAL_DEMAND_DATA = [
  { season: "Spring", vegetables: 300, fruits: 250, grains: 400, spices: 150 },
  { season: "Summer", vegetables: 450, fruits: 500, grains: 200, spices: 180 },
  { season: "Monsoon", vegetables: 380, fruits: 400, grains: 350, spices: 200 },
  { season: "Winter", vegetables: 500, fruits: 300, grains: 600, spices: 250 },
];

export const STATE_DEMAND_DATA = [
  { state: "Maharashtra", demand: 1200 },
  { state: "Karnataka", demand: 980 },
  { state: "Punjab", demand: 850 },
  { state: "UP", demand: 1100 },
  { state: "MP", demand: 720 },
  { state: "Gujarat", demand: 680 },
  { state: "Rajasthan", demand: 590 },
  { state: "TN", demand: 650 },
  { state: "AP", demand: 570 },
  { state: "WB", demand: 540 },
];

export interface BuyerMatch {
  buyerName: string;
  buyerType: "Consumer" | "Retailer" | "Restaurant" | "Institution" | "Bulk Buyer";
  location: string;
  quantityNeeded: number;
  unit: "kg" | "tonne";
  matchScore: number;
  priceOffered: number;
  deliveryDate: string;
}

export const BUYER_MATCHES: BuyerMatch[] = [
  { buyerName: "Fresh Mart Retailers", buyerType: "Retailer", location: "Pune, Maharashtra", quantityNeeded: 200, unit: "kg", matchScore: 95, priceOffered: 42, deliveryDate: "2026-09-20" },
  { buyerName: "Green Leaf Restaurant", buyerType: "Restaurant", location: "Mumbai, Maharashtra", quantityNeeded: 50, unit: "kg", matchScore: 88, priceOffered: 44, deliveryDate: "2026-09-19" },
  { buyerName: "City Public School", buyerType: "Institution", location: "Nashik, Maharashtra", quantityNeeded: 100, unit: "kg", matchScore: 82, priceOffered: 40, deliveryDate: "2026-09-21" },
  { buyerName: "AgriBulk Traders", buyerType: "Bulk Buyer", location: "Nagpur, Maharashtra", quantityNeeded: 2, unit: "tonne", matchScore: 78, priceOffered: 38, deliveryDate: "2026-09-22" },
  { buyerName: "Daily Fresh Consumer", buyerType: "Consumer", location: "Nashik, Maharashtra", quantityNeeded: 5, unit: "kg", matchScore: 72, priceOffered: 45, deliveryDate: "2026-09-18" },
];

export interface OrderAggregation {
  id: string;
  orders: number;
  totalQuantity: number;
  unit: "kg";
  logisticsSaving: number;
  route: string;
  deliveryDate: string;
}

export const ORDER_AGGREGATIONS: OrderAggregation[] = [
  { id: "agg1", orders: 3, totalQuantity: 150, unit: "kg", logisticsSaving: 800, route: "Nashik → Pune → Mumbai", deliveryDate: "2026-09-20" },
  { id: "agg2", orders: 5, totalQuantity: 280, unit: "kg", logisticsSaving: 1200, route: "Nashik → Aurangabad → Nagpur", deliveryDate: "2026-09-21" },
  { id: "agg3", orders: 2, totalQuantity: 80, unit: "kg", logisticsSaving: 450, route: "Nashik → Dhule → Jalgaon", deliveryDate: "2026-09-19" },
];

export interface VehicleInfo {
  id: string;
  type: string;
  capacity: string;
  allocated: boolean;
  route: string;
  driver: string;
  status: "Available" | "In Transit" | "Loading" | "Maintenance";
}

export const VEHICLES: VehicleInfo[] = [
  { id: "V001", type: "Mini Truck", capacity: "500 kg", allocated: true, route: "Nashik → Pune", driver: "Ramesh Kumar", status: "In Transit" },
  { id: "V002", type: "Pickup Van", capacity: "250 kg", allocated: true, route: "Nashik → Mumbai", driver: "Suresh Patil", status: "Loading" },
  { id: "V003", type: "Tempo", capacity: "1000 kg", allocated: false, route: "-", driver: "Mahesh Yadav", status: "Available" },
  { id: "V004", type: "Truck", capacity: "5 tonne", allocated: true, route: "Nashik → Nagpur → Aurangabad", driver: "Vijay Singh", status: "In Transit" },
  { id: "V005", type: "Mini Truck", capacity: "500 kg", allocated: false, route: "-", driver: "Anil Sharma", status: "Maintenance" },
];

export interface WastageAlert {
  product: string;
  farmer: string;
  state: string;
  quantity: number;
  unit: "kg";
  daysLeft: number;
  suggestedAction: string;
  suggestedPriceDrop: number;
}

export const WASTAGE_ALERTS: WastageAlert[] = [
  { product: "Fresh Tomato", farmer: "Green Valley FPO", state: "Maharashtra", quantity: 80, unit: "kg", daysLeft: 3, suggestedAction: "Quick sale to nearby buyers", suggestedPriceDrop: 10 },
  { product: "Spinach", farmer: "Organic Greens Farm", state: "Karnataka", quantity: 30, unit: "kg", daysLeft: 2, suggestedAction: "Urgent sale - reduce price", suggestedPriceDrop: 15 },
  { product: "Banana", farmer: "Kerala Banana Cooperative", state: "Kerala", quantity: 100, unit: "kg", daysLeft: 4, suggestedAction: "Offer to nearby restaurants", suggestedPriceDrop: 8 },
  { product: "Green Chilli", farmer: "Green Valley FPO", state: "Maharashtra", quantity: 40, unit: "kg", daysLeft: 5, suggestedAction: "Bundle with other orders", suggestedPriceDrop: 5 },
  { product: "Coriander Leaves", farmer: "Organic Greens Farm", state: "Karnataka", quantity: 15, unit: "kg", daysLeft: 2, suggestedAction: "Urgent sale - reduce price", suggestedPriceDrop: 20 },
];

export interface DeliveryStep {
  step: string;
  status: "completed" | "current" | "pending";
  location: string;
  timestamp: string;
}

export const DELIVERY_STEPS: DeliveryStep[] = [
  { step: "Order Confirmed", status: "completed", location: "FarmConnect Platform", timestamp: "17 Sep, 09:00 AM" },
  { step: "Picked Up", status: "completed", location: "Green Valley Farm, Nashik", timestamp: "17 Sep, 02:00 PM" },
  { step: "At Collection Center", status: "completed", location: "Nashik Collection Center", timestamp: "17 Sep, 04:30 PM" },
  { step: "In Transit", status: "current", location: "En route Pune", timestamp: "17 Sep, 06:00 PM" },
  { step: "Out for Delivery", status: "pending", location: "Pune Hub", timestamp: "Expected 18 Sep, 08:00 AM" },
  { step: "Delivered", status: "pending", location: "Customer Address, Pune", timestamp: "Expected 18 Sep, 11:00 AM" },
];

export interface TraceabilityInfo {
  step: string;
  label: string;
  details: string;
  location: string;
  date: string;
}

export const TRACEABILITY_STEPS: TraceabilityInfo[] = [
  { step: "farm", label: "Farm", details: "Green Valley FPO, Nashik", location: "Nashik, Maharashtra", date: "16 Sep 2026" },
  { step: "collection", label: "Collection Center", details: "Nashik Agri Collection Hub", location: "Nashik, Maharashtra", date: "17 Sep 2026" },
  { step: "transport", label: "Transport", details: "Vehicle V001 - Mini Truck", location: "Nashik → Pune", date: "17 Sep 2026" },
  { step: "buyer", label: "Buyer", details: "Delivered to Customer", location: "Pune, Maharashtra", date: "18 Sep 2026" },
];
