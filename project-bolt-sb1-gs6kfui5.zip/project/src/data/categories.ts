export type CategoryId =
  | "vegetables"
  | "fruits"
  | "grains"
  | "pulses"
  | "spices"
  | "oilseeds"
  | "millets"
  | "organic"
  | "other";

export interface Category {
  id: CategoryId;
  name: string;
  image: string;
  description: string;
}

export const CATEGORIES: Category[] = [
  {
    id: "vegetables",
    name: "Vegetables",
    image: "https://images.pexels.com/photos/37321079/pexels-photo-37321079.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description: "Fresh vegetables from farms across India",
  },
  {
    id: "fruits",
    name: "Fruits",
    image: "https://images.pexels.com/photos/7543169/pexels-photo-7543169.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description: "Seasonal fruits from orchards nationwide",
  },
  {
    id: "grains",
    name: "Grains",
    image: "https://images.pexels.com/photos/36346840/pexels-photo-36346840.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description: "Rice, wheat, maize and more grains",
  },
  {
    id: "pulses",
    name: "Pulses",
    image: "https://images.pexels.com/photos/34940646/pexels-photo-34940646.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description: "Lentils, chickpeas and protein-rich pulses",
  },
  {
    id: "spices",
    name: "Spices",
    image: "https://images.pexels.com/photos/877220/pexels-photo-877220.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description: "Aromatic spices from India's spice heartlands",
  },
  {
    id: "oilseeds",
    name: "Oilseeds",
    image: "https://images.pexels.com/photos/39150995/pexels-photo-39150995.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description: "Mustard, groundnut and oil-rich seeds",
  },
  {
    id: "millets",
    name: "Millets",
    image: "https://images.pexels.com/photos/18275951/pexels-photo-18275951.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description: "Nutritious millets - bajra, jowar, ragi",
  },
  {
    id: "organic",
    name: "Organic Produce",
    image: "https://images.pexels.com/photos/28991058/pexels-photo-28991058.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description: "Certified organic produce, chemical-free",
  },
  {
    id: "other",
    name: "Other Farm Produce",
    image: "https://images.pexels.com/photos/5807481/pexels-photo-5807481.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description: "Miscellaneous farm produce from across India",
  },
];

export function getCategory(id: CategoryId): Category | undefined {
  return CATEGORIES.find((c) => c.id === id);
}

export function getCategoryName(id: CategoryId): string {
  return getCategory(id)?.name ?? id;
}
