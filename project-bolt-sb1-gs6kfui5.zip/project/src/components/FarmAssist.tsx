import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Sparkles } from "lucide-react";
import { PRODUCTS } from "@/data/products";
import { DEMAND_FORECASTS } from "@/data/aiInsights";

interface ChatMessage {
  role: "user" | "bot";
  text: string;
}

function generateResponse(query: string): string {
  const q = query.toLowerCase();

  if (q.includes("tomato") || q.includes("500 kg")) {
    const tomato = PRODUCTS.find((p) => p.name.toLowerCase().includes("tomato"));
    if (tomato) {
      return `I can help you list your tomatoes! I found a similar product on the marketplace:\n\n**${tomato.name}**\nFarmer: ${tomato.farmer}\nCurrent Price: ₹${tomato.pricePerUnit}/${tomato.unit}\nLocation: ${tomato.city}, ${tomato.state}\n\nPlease confirm the quality, harvest date, and expected price to list your produce.`;
    }
  }

  if (q.includes("onion") || q.includes("200 kg")) {
    const onions = PRODUCTS.filter((p) => p.name.toLowerCase().includes("onion"));
    if (onions.length > 0) {
      const list = onions.map((o) => `${o.name} - ₹${o.pricePerUnit}/${o.unit} (${o.city}, ${o.state})`).join("\n");
      return `I found available onion supplies from nearby farmers. You can compare price, quality, farmer location and delivery time:\n\n${list}\n\nWould you like to add any of these to your cart?`;
    }
  }

  if (q.includes("price") || q.includes("demand") || q.includes("forecast")) {
    const top = DEMAND_FORECASTS.slice(0, 3).map(
      (d) => `${d.product}: Demand ${d.demandStatus} - Recommended ₹${d.recommendedPrice}/${d.unit}`
    ).join("\n");
    return `Here are the latest AI demand insights:\n\n${top}\n\nVisit the AI Insights page for detailed forecasts and market trends.`;
  }

  if (q.includes("order") || q.includes("delivery") || q.includes("track")) {
    return `You can track your orders from the Orders page. Delivery tracking shows the full journey from Farm → Collection Center → Transport → Buyer with live status updates.`;
  }

  if (q.includes("farmer") || q.includes("register") || q.includes("sell")) {
    return `To start selling on FarmConnect:\n1. Register as a farmer\n2. List your produce\n3. Get AI demand insights\n4. Connect with buyers\n5. Receive payment\n\nVisit the Farmer Registration page to get started!`;
  }

  if (q.includes("buyer") || q.includes("buy")) {
    return `As a buyer you can:\n- Browse fresh products from across India\n- Filter by state, category, and price\n- View product details and farmer profiles\n- Add to cart and checkout securely\n- Track your delivery on the map\n\nStart by visiting the Products page!`;
  }

  if (q.includes("logistics") || q.includes("vehicle") || q.includes("route")) {
    return `The Logistics Dashboard shows available vehicles, route optimization, and delivery tracking. Farmers can aggregate nearby orders to save on logistics costs. Visit the Logistics page for details.`;
  }

  if (q.includes("wastage") || q.includes("expiry") || q.includes("fresh")) {
    return `Our Wastage Monitoring system tracks products nearing their freshness limit and suggests quick-sale options with price adjustments. This helps reduce agricultural wastage across the supply chain.`;
  }

  if (q.includes("hello") || q.includes("hi") || q.includes("hey")) {
    return `Hello! I'm FarmAssist, your AI farming assistant. I can help you with:\n- Finding products\n- Listing produce\n- Market prices and demand\n- Order and delivery tracking\n- Marketplace guidance\n\nHow can I help you today?`;
  }

  return `I can help you with finding products, listing produce, market prices, demand predictions, order status, delivery tracking, and marketplace guidance. Try asking about tomatoes, onions, prices, or how to sell your produce!`;
}

export default function FarmAssist() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: "bot", text: "Hi! I'm FarmAssist, your AI Farming Assistant. How can I help you today?" },
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg = input;
    setMessages((prev) => [...prev, { role: "user", text: userMsg }]);
    setInput("");
    setTimeout(() => {
      const response = generateResponse(userMsg);
      setMessages((prev) => [...prev, { role: "bot", text: response }]);
    }, 500);
  };

  const quickPrompts = [
    "I need 200 kg onions",
    "I have 500 kg tomatoes available next week",
    "Show me demand forecast",
    "How to track my order?",
  ];

  return (
    <>
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-5 right-5 z-50 flex items-center gap-2 px-4 py-3 bg-green-600 hover:bg-green-700 text-white rounded-full shadow-xl transition-all hover:scale-105"
        >
          <MessageCircle className="w-5 h-5" />
          <span className="text-sm font-medium hidden sm:block">FarmAssist</span>
        </button>
      )}

      {open && (
        <div className="fixed bottom-5 right-5 z-50 w-[360px] max-w-[calc(100vw-2rem)] h-[500px] max-h-[calc(100vh-2rem)] bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-green-600 to-green-700 text-white">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-sm">FarmAssist</div>
                <div className="text-[10px] text-green-100">Your AI Farming Assistant</div>
              </div>
            </div>
            <button onClick={() => setOpen(false)} className="p-1 hover:bg-white/20 rounded-lg transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm whitespace-pre-line ${
                    msg.role === "user"
                      ? "bg-green-600 text-white rounded-br-sm"
                      : "bg-white border border-gray-200 text-gray-700 rounded-bl-sm"
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            {messages.length <= 2 && (
              <div className="space-y-1.5 pt-2">
                <div className="text-[10px] text-gray-400 px-1">Quick questions:</div>
                {quickPrompts.map((prompt) => (
                  <button
                    key={prompt}
                    onClick={() => {
                      setInput(prompt);
                      setTimeout(() => {
                        setMessages((prev) => [...prev, { role: "user", text: prompt }]);
                        setTimeout(() => {
                          setMessages((prev) => [...prev, { role: "bot", text: generateResponse(prompt) }]);
                        }, 500);
                      }, 100);
                      setInput("");
                    }}
                    className="block w-full text-left px-3 py-1.5 text-xs text-green-700 bg-green-50 hover:bg-green-100 rounded-lg transition-colors"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="p-3 border-t border-gray-100 bg-white">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder="Ask FarmAssist..."
                className="flex-1 px-3 py-2 text-sm bg-gray-50 border border-gray-200 rounded-full focus:outline-none focus:border-green-500 focus:bg-white transition-colors"
              />
              <button
                onClick={handleSend}
                className="w-9 h-9 flex items-center justify-center bg-green-600 hover:bg-green-700 text-white rounded-full transition-colors shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
