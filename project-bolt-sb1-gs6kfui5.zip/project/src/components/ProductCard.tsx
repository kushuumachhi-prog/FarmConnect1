import { Link } from "react-router-dom";
import { BadgeCheck, Heart, MapPin, ShoppingCart, Eye } from "lucide-react";
import type { Product } from "@/data/products";
import { useStore } from "@/store/StoreContext";

interface Props {
  product: Product;
}

export default function ProductCard({ product }: Props) {
  const { addToCart, toggleWishlist, isWishlisted } = useStore();
  const wished = isWishlisted(product.id);

  return (
    <div className="group bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-xl hover:border-green-300 transition-all duration-300 flex flex-col">
      <Link to={`/product/${product.id}`} className="relative overflow-hidden block">
        <div className="aspect-[4/3] overflow-hidden bg-gray-100">
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
        <span className="absolute top-2 left-2 px-2 py-1 text-[10px] font-bold uppercase tracking-wide bg-green-600 text-white rounded-full shadow-sm">
          Fresh
        </span>
        {product.isOrganic && (
          <span className="absolute top-2 right-10 px-2 py-1 text-[10px] font-bold uppercase tracking-wide bg-amber-500 text-white rounded-full shadow-sm">
            Organic
          </span>
        )}
        <button
          onClick={(e) => {
            e.preventDefault();
            toggleWishlist(product.id);
          }}
          className="absolute top-2 right-2 w-8 h-8 rounded-full bg-white/90 flex items-center justify-center shadow-sm hover:bg-white transition-colors"
        >
          <Heart className={`w-4 h-4 ${wished ? "fill-red-500 text-red-500" : "text-gray-400"}`} />
        </button>
      </Link>

      <div className="p-3 sm:p-4 flex flex-col flex-1">
        <Link to={`/product/${product.id}`}>
          <h3 className="font-semibold text-gray-900 text-sm sm:text-base group-hover:text-green-700 transition-colors line-clamp-1">
            {product.name}
          </h3>
        </Link>
        <div className="flex items-center gap-1 mt-1">
          <span className="text-xs text-gray-500">{product.farmer}</span>
          {product.verified && <BadgeCheck className="w-3.5 h-3.5 text-blue-500" />}
        </div>
        <div className="flex items-center gap-1 text-xs text-gray-400 mt-0.5">
          <MapPin className="w-3 h-3" />
          <span>{product.city}, {product.state}</span>
        </div>

        <div className="flex items-center gap-2 mt-2">
          <span className="px-2 py-0.5 text-[10px] font-medium bg-green-50 text-green-700 rounded-md">
            {product.grade}
          </span>
          <span className="text-xs text-gray-500">
            {product.availableQty} {product.unit} available
          </span>
        </div>

        <div className="flex items-end justify-between mt-2 mb-3">
          <div>
            <span className="text-lg font-bold text-gray-900">₹{product.pricePerUnit}</span>
            <span className="text-xs text-gray-500">/{product.unit}</span>
          </div>
          <span className="text-[10px] text-gray-400">
            {new Date(product.harvestDate).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
          </span>
        </div>

        <div className="flex gap-2 mt-auto">
          <Link
            to={`/product/${product.id}`}
            className="flex-1 flex items-center justify-center gap-1 px-3 py-2 text-xs font-medium text-green-700 bg-green-50 hover:bg-green-100 rounded-lg transition-colors"
          >
            <Eye className="w-3.5 h-3.5" />
            View
          </Link>
          <button
            onClick={() => addToCart(product)}
            className="flex-1 flex items-center justify-center gap-1 px-3 py-2 text-xs font-medium text-white bg-green-600 hover:bg-green-700 rounded-lg transition-colors"
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            Add
          </button>
        </div>
      </div>
    </div>
  );
}
