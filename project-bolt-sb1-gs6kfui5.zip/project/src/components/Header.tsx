import { Link, useNavigate, useLocation } from "react-router-dom";
import { useState, useRef, useEffect } from "react";
import {
  Search,
  ShoppingCart,
  MapPin,
  Menu,
  X,
  Plus,
  Sprout,
  ChevronDown,
} from "lucide-react";
import { useStore } from "@/store/StoreContext";
import { INDIAN_STATES, ALL_INDIA, getCitiesForState } from "@/data/states";

export default function Header() {
  const { cartCount, location, setLocation } = useStore();
  const navigate = useNavigate();
  const routeLocation = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [locationOpen, setLocationOpen] = useState(false);
  const [selectedState, setSelectedState] = useState<string>(ALL_INDIA);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const locationRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (locationRef.current && !locationRef.current.contains(e.target as Node)) {
        setLocationOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  const navLinks = [
    { label: "Home", path: "/" },
    { label: "Products", path: "/products" },
    { label: "Farmers", path: "/farmers" },
    { label: "Orders", path: "/orders" },
    { label: "AI Insights", path: "/ai-insights" },
    { label: "About", path: "/about" },
  ];

  const isActive = (path: string) =>
    path === "/" ? routeLocation.pathname === "/" : routeLocation.pathname.startsWith(path);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-600 to-green-700 flex items-center justify-center shadow-md">
              <Sprout className="w-6 h-6 text-white" />
            </div>
            <div className="hidden sm:block">
              <div className="text-xl font-bold text-gray-900 leading-none">FarmConnect</div>
              <div className="text-[10px] text-gray-500 font-medium tracking-wide">
                Fresh Produce - Better Tomorrow
              </div>
            </div>
          </Link>

          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-md relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search fresh products..."
              className="w-full pl-10 pr-4 py-2.5 text-sm bg-gray-50 border border-gray-200 rounded-full focus:outline-none focus:border-green-500 focus:bg-white transition-colors"
            />
          </form>

          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <div ref={locationRef} className="relative">
              <button
                onClick={() => setLocationOpen(!locationOpen)}
                className="flex items-center gap-1 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <MapPin className="w-4 h-4 text-green-600" />
                <span className="hidden lg:inline max-w-[100px] truncate">{location}</span>
                <ChevronDown className="w-3 h-3" />
              </button>
              {locationOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-gray-200 py-2 max-h-96 overflow-y-auto z-50">
                  <button
                    onClick={() => {
                      setLocation(ALL_INDIA);
                      setSelectedState(ALL_INDIA);
                      setLocationOpen(false);
                    }}
                    className={`w-full text-left px-4 py-2 text-sm hover:bg-green-50 transition-colors ${
                      location === ALL_INDIA ? "text-green-700 font-semibold bg-green-50" : "text-gray-700"
                    }`}
                  >
                    {ALL_INDIA}
                  </button>
                  <div className="border-t border-gray-100 my-1" />
                  <div className="px-4 py-1 text-xs font-semibold text-gray-400 uppercase">States & UTs</div>
                  {INDIAN_STATES.map((s) => (
                    <div key={s.name}>
                      <button
                        onClick={() => setSelectedState(s.name)}
                        className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${
                          selectedState === s.name ? "text-green-700 font-semibold bg-green-50" : "text-gray-700"
                        }`}
                      >
                        {s.name}
                      </button>
                      {selectedState === s.name && (
                        <div className="pl-8 bg-gray-50">
                          {getCitiesForState(s.name).map((city) => (
                            <button
                              key={city}
                              onClick={() => {
                                setLocation(`${city}, ${s.name}`);
                                setLocationOpen(false);
                              }}
                              className="w-full text-left px-4 py-1.5 text-xs text-gray-600 hover:text-green-700 hover:bg-green-50 transition-colors"
                            >
                              {city}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <Link
              to="/cart"
              className="relative p-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-green-600 text-white text-xs font-bold rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>

            <Link
              to="/login"
              className="hidden sm:block px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
            >
              Login
            </Link>

            <Link
              to="/farmer/add-product"
              className="hidden sm:flex items-center gap-1 px-4 py-2 text-sm font-medium text-white bg-green-600 hover:bg-green-700 rounded-lg transition-colors shadow-sm"
            >
              <Plus className="w-4 h-4" />
              Add Product
            </Link>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden pb-4 border-t border-gray-100 pt-2">
            <form onSubmit={handleSearch} className="relative mb-3">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search fresh products..."
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-gray-50 border border-gray-200 rounded-full focus:outline-none focus:border-green-500"
              />
            </form>
            <nav className="flex flex-col gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`px-4 py-2.5 text-sm rounded-lg transition-colors ${
                    isActive(link.path)
                      ? "text-green-700 bg-green-50 font-semibold"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  {link.label}
                </Link>
              ))}
              <Link
                to="/login"
                className="px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                Login / Register
              </Link>
              <Link
                to="/farmer/add-product"
                className="flex items-center gap-1 px-4 py-2.5 text-sm font-medium text-white bg-green-600 rounded-lg"
              >
                <Plus className="w-4 h-4" /> Add Product
              </Link>
            </nav>
          </div>
        )}

        <nav className="hidden md:flex items-center gap-1 -mt-1 pb-2">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`px-3 py-1.5 text-sm rounded-lg transition-colors ${
                isActive(link.path)
                  ? "text-green-700 font-semibold"
                  : "text-gray-600 hover:text-green-700 hover:bg-green-50"
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
