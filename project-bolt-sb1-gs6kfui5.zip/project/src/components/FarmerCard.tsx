import { Link } from "react-router-dom";
import { BadgeCheck, MapPin, Star, ArrowRight } from "lucide-react";
import type { Farmer } from "@/data/farmers";

interface Props {
  farmer: Farmer;
}

export default function FarmerCard({ farmer }: Props) {
  return (
    <Link
      to={`/farmer/${farmer.id}`}
      className="group bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-xl hover:border-green-300 transition-all duration-300"
    >
      <div className="relative h-36 overflow-hidden bg-gray-100">
        <img
          src={farmer.image}
          alt={farmer.name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        {farmer.verified && (
          <span className="absolute top-2 right-2 flex items-center gap-1 px-2 py-1 text-[10px] font-bold bg-blue-500 text-white rounded-full shadow-sm">
            <BadgeCheck className="w-3 h-3" /> Verified
          </span>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-gray-900 text-sm group-hover:text-green-700 transition-colors line-clamp-1">
          {farmer.name}
        </h3>
        <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
          <MapPin className="w-3 h-3" />
          <span>{farmer.city}, {farmer.state}</span>
        </div>
        <div className="flex items-center gap-1 mt-2">
          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
          <span className="text-xs font-medium text-gray-700">{farmer.rating}</span>
          <span className="text-xs text-gray-400">· {farmer.productsCount} products</span>
        </div>
        <div className="flex flex-wrap gap-1 mt-2">
          {farmer.mainCrops.slice(0, 3).map((crop) => (
            <span key={crop} className="px-2 py-0.5 text-[10px] bg-gray-100 text-gray-600 rounded-md">
              {crop}
            </span>
          ))}
        </div>
        <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
          <span className="text-xs text-gray-500">{farmer.distance} km away</span>
          <span className="flex items-center gap-1 text-xs font-medium text-green-700 group-hover:gap-2 transition-all">
            View Profile <ArrowRight className="w-3.5 h-3.5" />
          </span>
        </div>
      </div>
    </Link>
  );
}
