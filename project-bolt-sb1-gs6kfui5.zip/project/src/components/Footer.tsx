import { Link } from "react-router-dom";
import { Sprout, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Youtube } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center">
                <Sprout className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-xl font-bold text-white">FarmConnect</div>
                <div className="text-[10px] text-gray-400">Fresh Produce - Better Tomorrow</div>
              </div>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">
              India's agricultural digital marketplace connecting verified farmers and FPOs directly with consumers, retailers, and bulk buyers.
            </p>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4 text-sm uppercase tracking-wide">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/" className="hover:text-green-400 transition-colors">Home</Link></li>
              <li><Link to="/products" className="hover:text-green-400 transition-colors">Products</Link></li>
              <li><Link to="/farmers" className="hover:text-green-400 transition-colors">Farmers</Link></li>
              <li><Link to="/ai-insights" className="hover:text-green-400 transition-colors">AI Insights</Link></li>
              <li><Link to="/about" className="hover:text-green-400 transition-colors">About Us</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4 text-sm uppercase tracking-wide">For Farmers</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/farmer/register" className="hover:text-green-400 transition-colors">Register as Farmer</Link></li>
              <li><Link to="/farmer/dashboard" className="hover:text-green-400 transition-colors">Farmer Dashboard</Link></li>
              <li><Link to="/farmer/add-product" className="hover:text-green-400 transition-colors">Add Product</Link></li>
              <li><Link to="/logistics" className="hover:text-green-400 transition-colors">Logistics Dashboard</Link></li>
              <li><Link to="/find-farmers" className="hover:text-green-400 transition-colors">Find Farmers on Map</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4 text-sm uppercase tracking-wide">Contact</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2"><Mail className="w-4 h-4 text-green-400" /> support@farmconnect.in</li>
              <li className="flex items-center gap-2"><Phone className="w-4 h-4 text-green-400" /> +91 1800 123 4567</li>
              <li className="flex items-center gap-2"><MapPin className="w-4 h-4 text-green-400" /> Bengaluru, Karnataka, India</li>
            </ul>
            <div className="flex gap-3 mt-4">
              <a href="#" className="w-9 h-9 rounded-full bg-gray-800 hover:bg-green-600 flex items-center justify-center transition-colors"><Facebook className="w-4 h-4" /></a>
              <a href="#" className="w-9 h-9 rounded-full bg-gray-800 hover:bg-green-600 flex items-center justify-center transition-colors"><Twitter className="w-4 h-4" /></a>
              <a href="#" className="w-9 h-9 rounded-full bg-gray-800 hover:bg-green-600 flex items-center justify-center transition-colors"><Instagram className="w-4 h-4" /></a>
              <a href="#" className="w-9 h-9 rounded-full bg-gray-800 hover:bg-green-600 flex items-center justify-center transition-colors"><Youtube className="w-4 h-4" /></a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-gray-500">© 2026 FarmConnect. All rights reserved. Made for Indian farmers.</p>
          <div className="flex gap-4 text-xs text-gray-500">
            <a href="#" className="hover:text-green-400">Privacy Policy</a>
            <a href="#" className="hover:text-green-400">Terms of Service</a>
            <a href="#" className="hover:text-green-400">Support</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
