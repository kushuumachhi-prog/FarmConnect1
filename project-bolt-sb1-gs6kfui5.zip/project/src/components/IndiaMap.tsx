import { useState } from "react";
import { BadgeCheck, MapPin, X } from "lucide-react";
import { FARMERS } from "@/data/farmers";
import { PRODUCTS } from "@/data/products";
import type { Farmer } from "@/data/farmers";

interface MarkerData {
  id: string;
  type: "farmer" | "collection" | "buyer";
  name: string;
  x: number;
  y: number;
  state: string;
  city: string;
  farmer?: Farmer;
}

const MARKER_TYPES = {
  farmer: { color: "bg-green-600", label: "Farmer/FPO" },
  collection: { color: "bg-amber-500", label: "Collection Center" },
  buyer: { color: "bg-blue-600", label: "Buyer" },
};

const MARKERS: MarkerData[] = [
  { id: "m1", type: "farmer", name: "Green Valley FPO", x: 28, y: 48, state: "Maharashtra", city: "Nashik" },
  { id: "m2", type: "farmer", name: "Shiv Shakti FPC", x: 29, y: 46, state: "Maharashtra", city: "Nashik" },
  { id: "m3", type: "farmer", name: "Punjab Rice Growers", x: 33, y: 12, state: "Punjab", city: "Ludhiana" },
  { id: "m4", type: "farmer", name: "Guntur Spice Farmers", x: 42, y: 68, state: "Andhra Pradesh", city: "Guntur" },
  { id: "m5", type: "farmer", name: "Ratnagiri Mango Growers", x: 25, y: 52, state: "Maharashtra", city: "Ratnagiri" },
  { id: "m6", type: "farmer", name: "Kerala Banana Coop", x: 22, y: 72, state: "Kerala", city: "Thrissur" },
  { id: "m7", type: "farmer", name: "Haryana Wheat Farmers", x: 32, y: 14, state: "Haryana", city: "Karnal" },
  { id: "m8", type: "farmer", name: "Malwa Pulse Producers", x: 35, y: 38, state: "Madhya Pradesh", city: "Indore" },
  { id: "m9", type: "farmer", name: "Telangana Turmeric Farmers", x: 38, y: 55, state: "Telangana", city: "Warangal" },
  { id: "m10", type: "farmer", name: "Himalayan Fresh Farms", x: 40, y: 18, state: "Himachal Pradesh", city: "Solan" },
  { id: "m11", type: "farmer", name: "Bengal Vegetable Growers", x: 55, y: 35, state: "West Bengal", city: "Siliguri" },
  { id: "m12", type: "farmer", name: "Organic Greens Farm", x: 33, y: 58, state: "Karnataka", city: "Bengaluru" },
  { id: "m13", type: "farmer", name: "Nagpur Citrus Farmers", x: 33, y: 50, state: "Maharashtra", city: "Nagpur" },
  { id: "m14", type: "farmer", name: "Kashmir Valley Orchards", x: 36, y: 8, state: "Jammu and Kashmir", city: "Srinagar" },
  { id: "m15", type: "farmer", name: "Western Ghats Spice Growers", x: 21, y: 70, state: "Kerala", city: "Idukki" },
  { id: "m16", type: "farmer", name: "Saurashtra Groundnut Farmers", x: 18, y: 42, state: "Gujarat", city: "Junagadh" },
  { id: "m17", type: "farmer", name: "Rajasthan Spice Farmers", x: 28, y: 28, state: "Rajasthan", city: "Kota" },
  { id: "m18", type: "farmer", name: "Agra Farmers Collective", x: 42, y: 26, state: "Uttar Pradesh", city: "Agra" },
  { id: "m19", type: "farmer", name: "Karnataka Millet FPO", x: 31, y: 56, state: "Karnataka", city: "Mysuru" },
  { id: "m20", type: "farmer", name: "South Indian Tropical Farms", x: 33, y: 63, state: "Tamil Nadu", city: "Coimbatore" },
  { id: "c1", type: "collection", name: "Nashik Collection Center", x: 28, y: 47, state: "Maharashtra", city: "Nashik" },
  { id: "c2", type: "collection", name: "Pune Agri Hub", x: 27, y: 50, state: "Maharashtra", city: "Pune" },
  { id: "c3", type: "collection", name: "Bengaluru Agri Hub", x: 33, y: 58, state: "Karnataka", city: "Bengaluru" },
  { id: "c4", type: "collection", name: "Indore Collection Center", x: 35, y: 38, state: "Madhya Pradesh", city: "Indore" },
  { id: "c5", type: "collection", name: "Hyderabad Agri Hub", x: 37, y: 54, state: "Telangana", city: "Hyderabad" },
  { id: "b1", type: "buyer", name: "Fresh Mart Retailers", x: 27, y: 50, state: "Maharashtra", city: "Pune" },
  { id: "b2", type: "buyer", name: "Mumbai Bulk Buyers", x: 24, y: 48, state: "Maharashtra", city: "Mumbai" },
  { id: "b3", type: "buyer", name: "Delhi Wholesale Market", x: 38, y: 18, state: "Delhi", city: "New Delhi" },
  { id: "b4", type: "buyer", name: "Chennai Retail Hub", x: 35, y: 66, state: "Tamil Nadu", city: "Chennai" },
  { id: "b5", type: "buyer", name: "Kolkata Buyers", x: 56, y: 35, state: "West Bengal", city: "Kolkata" },
];

MARKERS.forEach((m) => {
  if (m.type === "farmer") {
    m.farmer = FARMERS.find((f) => f.name === m.name);
  }
});

interface Props {
  height?: string;
  showFilters?: boolean;
}

export default function IndiaMap({ height = "500px", showFilters = true }: Props) {
  const [selected, setSelected] = useState<MarkerData | null>(null);
  const [filter, setFilter] = useState<"all" | "farmer" | "collection" | "buyer">("all");
  const [stateFilter, setStateFilter] = useState<string>("All India");

  const statesWithMarkers = ["All India", ...new Set(MARKERS.map((m) => m.state))].sort();

  const visibleMarkers = MARKERS.filter((m) => {
    if (filter !== "all" && m.type !== filter) return false;
    if (stateFilter !== "All India" && m.state !== stateFilter) return false;
    return true;
  });

  return (
    <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
      {showFilters && (
        <div className="flex flex-wrap gap-2 p-4 border-b border-gray-100 bg-gray-50">
          {(["all", "farmer", "collection", "buyer"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setFilter(t)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                filter === t
                  ? "bg-green-600 text-white"
                  : "bg-white text-gray-600 border border-gray-200 hover:border-green-300"
              }`}
            >
              {t === "all" ? "All Markers" : MARKER_TYPES[t].label}
            </button>
          ))}
          <select
            value={stateFilter}
            onChange={(e) => setStateFilter(e.target.value)}
            className="px-3 py-1.5 text-xs font-medium rounded-lg border border-gray-200 bg-white text-gray-600 focus:outline-none focus:border-green-500"
          >
            {statesWithMarkers.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
      )}

      <div className="relative" style={{ height }}>
        <svg viewBox="0 0 100 100" className="w-full h-full" preserveAspectRatio="xMidYMid meet">
          <defs>
            <radialGradient id="indiaBg" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f0fdf4" />
              <stop offset="100%" stopColor="#dcfce7" />
            </radialGradient>
          </defs>
          <rect width="100" height="100" fill="url(#indiaBg)" />

          <path
            d="M 35 5 L 40 8 L 42 12 L 45 15 L 48 20 L 50 25 L 55 28 L 58 32 L 56 36 L 52 38 L 48 42 L 45 45 L 42 48 L 40 52 L 38 56 L 36 60 L 34 65 L 33 70 L 30 72 L 25 70 L 22 68 L 20 65 L 18 60 L 16 55 L 15 50 L 16 45 L 18 40 L 20 35 L 22 30 L 25 25 L 28 20 L 30 15 L 32 10 Z"
            fill="#bbf7d0"
            stroke="#22c55e"
            strokeWidth="0.4"
            opacity="0.7"
          />
          <path
            d="M 38 5 L 42 7 L 45 10 L 48 14 L 50 18 L 52 22 L 55 26 L 58 30 L 60 34 L 58 38 L 55 40 L 52 42 L 48 44 L 45 46 L 42 48 L 40 50 L 38 52 L 36 54 L 34 56 L 32 58 L 30 60 L 28 62 L 26 64 L 24 66 L 22 68 L 20 66 L 18 62 L 16 58 L 14 54 L 12 50 L 10 46 L 8 42 L 6 38 L 5 34 L 4 30 L 3 26 L 2 22 L 1 18 L 0 14 L 0 10 L 2 6 L 5 4 L 10 3 L 15 4 L 20 5 L 25 4 L 30 5 L 35 5 Z"
            fill="#86efac"
            stroke="#16a34a"
            strokeWidth="0.3"
            opacity="0.5"
          />

          {visibleMarkers.map((m) => (
            <g key={m.id} onClick={() => setSelected(m)} className="cursor-pointer">
              <circle
                cx={m.x}
                cy={m.y}
                r={selected?.id === m.id ? 2.5 : 1.5}
                fill={m.type === "farmer" ? "#16a34a" : m.type === "collection" ? "#f59e0b" : "#2563eb"}
                stroke="white"
                strokeWidth="0.3"
                className="transition-all"
              >
                <animate
                  attributeName="r"
                  values="1.5;2;1.5"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
            </g>
          ))}
        </svg>

        <div className="absolute bottom-3 left-3 flex flex-col gap-1 bg-white/90 rounded-lg p-2 text-xs shadow-sm">
          {Object.entries(MARKER_TYPES).map(([key, val]) => (
            <div key={key} className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-full ${val.color}`} />
              <span className="text-gray-600">{val.label}</span>
            </div>
          ))}
        </div>

        <div className="absolute top-3 right-3 bg-white/90 rounded-lg px-3 py-1.5 text-xs text-gray-600 shadow-sm">
          {visibleMarkers.length} markers visible
        </div>

        {selected && (
          <div className="absolute top-3 left-3 max-w-xs bg-white rounded-xl shadow-xl border border-gray-200 p-4 z-10">
            <button
              onClick={() => setSelected(null)}
              className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-1 mb-1">
              <span className={`px-2 py-0.5 text-[10px] font-bold text-white rounded-md ${MARKER_TYPES[selected.type].color}`}>
                {MARKER_TYPES[selected.type].label}
              </span>
            </div>
            <h4 className="font-semibold text-gray-900 text-sm">{selected.name}</h4>
            <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
              <MapPin className="w-3 h-3" />
              {selected.city}, {selected.state}
            </div>
            {selected.farmer && (
              <div className="mt-2 pt-2 border-t border-gray-100">
                <div className="flex items-center gap-1 text-xs text-gray-600">
                  {selected.farmer.verified && <BadgeCheck className="w-3.5 h-3.5 text-blue-500" />}
                  Verified Farmer
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {selected.farmer.mainCrops.join(", ")}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {selected.farmer.productsCount} products · {selected.farmer.distance} km away
                </div>
                <div className="mt-2 flex flex-wrap gap-1">
                  {PRODUCTS.filter((p) => p.farmerId === selected.farmer!.id).slice(0, 3).map((p) => (
                    <span key={p.id} className="px-2 py-0.5 text-[10px] bg-green-50 text-green-700 rounded-md">
                      {p.name} - ₹{p.pricePerUnit}/{p.unit}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
