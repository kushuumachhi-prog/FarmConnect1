import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database table names
export const TABLES = {
  FARMERS: "farmers",
  PRODUCTS: "products",
  ORDERS: "orders",
  ORDER_ITEMS: "order_items",
} as const;
