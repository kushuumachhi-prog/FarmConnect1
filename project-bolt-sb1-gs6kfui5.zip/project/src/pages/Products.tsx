import { useSearchParams } from "react-router-dom";
import { useState, useMemo } from "react";
import { SlidersHorizontal, X, MapPin } from "lucide-react";
import { useStore } from "@/store/StoreContext";
import { CATEGORIES } from "@/data/categories";
import { INDIAN_STATES, ALL_INDIA, getCitiesForState } from "@/data/states";
import ProductCard from "@/components/ProductCard";
import type { CategoryId } from "@/data/categories";

export default function Products() {
  const { products, location } = useStore();
  const [searchParams, setSearchParams] = useSearchParams();
  const [showFilters, setShowFilters] = useState(false);

  const search = searchParams.get("search") || "";
  const category = searchParams.get("category") || "";
  const stateFilter = searchParams.get("state") || "";
  const cityFilter = searchParams.get("city") || "";
  const sortBy = searchParams.get("sort") || "newest";
  const minPrice = searchParams.get("minPrice") || "";
  const maxPrice = searchParams.get("maxPrice") || "";
  const gradeFilter = searchParams.get("grade") || "";

  const setParam = (key: string, value: string) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value);
    else next.delete(key);
    setSearchParams(next);
  };

  const filtered = useMemo(() => {
    let result = [...products];

    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.farmer.toLowerCase().includes(q) ||
          p.state.toLowerCase().includes(q) ||
          p.city.toLowerCase().includes(q)
      );
    }
    if (category) result = result.filter((p) => p.category === (category as CategoryId));
    if (stateFilter && stateFilter !== ALL_INDIA) result = result.filter((p) => p.state === stateFilter);
    if (cityFilter) result = result.filter((p) => p.city === cityFilter);
    if (gradeFilter) result = result.filter((p) => p.grade === gradeFilter);
    if (minPrice) result = result.filter((p) => p.pricePerUnit >= Number(minPrice));
    if (maxPrice) result = result.filter((p) => p.pricePerUnit <= Number(maxPrice));

    switch (sortBy) {
      case "price-low": result.sort((a, b) => a.pricePerUnit - b.pricePerUnit); break;
      case "price-high": result.sort((a, b) => b.pricePerUnit - a.pricePerUnit); break;
      case "freshness": result.sort((a, b) => new Date(b.harvestDate).getTime() - new Date(a.harvestDate).getTime()); break;
      case "available": result.sort((a, b) => b.availableQty - a.availableQty); break;
      default: break;
    }
    return result;
  }, [products, search, category, stateFilter, cityFilter, sortBy, minPrice, maxPrice, gradeFilter]);

  const cities = stateFilter ? getCitiesForState(stateFilter) : [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Fresh Products</h1>
          <p className="text-sm text-gray-500 mt-1">
            {filtered.length} products found
            {location !== ALL_INDIA && ` in ${location}`}
          </p>
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-200 rounded-lg hover:border-green-300 lg:hidden"
        >
          <SlidersHorizontal className="w-4 h-4" /> Filters
        </button>
      </div>

      <div className="flex gap-6">
        {/* Filters Sidebar */}
        <aside className={`${showFilters ? "fixed inset-0 z-50 bg-black/50 lg:bg-transparent lg:static lg:z-auto" : "hidden"} lg:block w-full lg:w-64 shrink-0`}>
          <div className={`${showFilters ? "fixed right-0 top-0 bottom-0 w-72 bg-white p-4 overflow-y-auto lg:static lg:w-full lg:p-0" : ""} lg:bg-transparent`}`}>
            <div className="flex items-center justify-between mb-4 lg:hidden">
              <h2 className="font-semibold">Filters</h2>
              <button onClick={() => setShowFilters(false)}><X className="w-5 h-5" /></button>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-2">Category</h3>
                <div className="space-y-1">
                  <button
                    onClick={() => setParam("category", "")}
                    className={`block w-full text-left px-2 py-1 text-xs rounded-md transition-colors ${
                      !category ? "bg-green-50 text-green-700 font-medium" : "text-gray-600 hover:bg-gray-50"
                    }`}
                  >
                    All Categories
                  </button>
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setParam("category", cat.id)}
                      className={`block w-full text-left px-2 py-1 text-xs rounded-md transition-colors ${
                        category === cat.id ? "bg-green-50 text-green-700 font-medium" : "text-gray-600 hover:bg-gray-50"
                      }`}
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-2">State</h3>
                <select
                  value={stateFilter}
                  onChange={(e) => { setParam("state", e.target.value); setParam("city", ""); }}
                  className="w-full px-2 py-1.5 text-xs border border-gray-200 rounded-md focus:outline-none focus:border-green-500"
                >
                  <option value="">All India</option>
                  {INDIAN_STATES.map((s) => (
                    <option key={s.name} value={s.name}>{s.name}</option>
                  ))}
                </select>
              </div>

              {cities.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-900 mb-2">City</h3>
                  <select
                    value={cityFilter}
                    onChange={(e) => setParam("city", e.target.value)}
                    className="w-full px-2 py-1.5 text-xs border border-gray-200 rounded-md focus:outline-none focus:border-green-500"
                  >
                    <option value="">All Cities</option>
                    {cities.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-2">Price Range (₹)</h3>
                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="Min"
                    value={minPrice}
                    onChange={(e) => setParam("minPrice", e.target.value)}
                    className="w-full px-2 py-1.5 text-xs border border-gray-200 rounded-md focus:outline-none focus:border-green-500"
                  />
                  <input
                    type="number"
                    placeholder="Max"
                    value={maxPrice}
                    onChange={(e) => setParam("maxPrice", e.target.value)}
                    className="w-full px-2 py-1.5 text-xs border border-gray-200 rounded-md focus:outline-none focus:border-green-500"
                  />
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-2">Quality Grade</h3>
                <div className="space-y-1">
                  {["Grade A", "Grade B", "Grade C"].map((g) => (
                    <button
                      key={g}
                      onClick={() => setParam("grade", gradeFilter === g ? "" : g)}
                      className={`block w-full text-left px-2 py-1 text-xs rounded-md transition-colors ${
                        gradeFilter === g ? "bg-green-50 text-green-700 font-medium" : "text-gray-600 hover:bg-gray-50"
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => setSearchParams(new URLSearchParams())}
                className="w-full px-3 py-2 text-xs font-medium text-gray-600 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
              >
                Clear All Filters
              </button>
            </div>
          </div>
        </aside>

        {/* Products Grid */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <MapPin className="w-4 h-4" />
              <span>{stateFilter || ALL_INDIA}{cityFilter ? `, ${cityFilter}` : ""}</span>
            </div>
            <select
              value={sortBy}
              onChange={(e) => setParam("sort", e.target.value)}
              className="px-3 py-2 text-sm border border-gray-200 rounded-lg bg-white focus:outline-none focus:border-green-500"
            >
              <option value="newest">Sort: Newest</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="freshness">Freshness</option>
              <option value="available">Most Available</option>
            </select>
          </div>

          {filtered.length === 0 ? (
            <div className="text-center py-20 text-gray-500">
              <p className="text-lg font-medium">No products found</p>
              <p className="text-sm mt-1">Try adjusting your filters or search query</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
              {filtered.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
