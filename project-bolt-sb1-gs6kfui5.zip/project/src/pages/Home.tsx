import { Link } from "react-router-dom";
import {
  Search, MapPin, ShoppingCart, Plus, Sprout, ChevronDown,
  BadgeCheck, Truck, TrendingUp, ShieldCheck, ArrowRight, Star,
  Users, Package, Store, Leaf
} from "lucide-react";
import { useStore } from "@/store/StoreContext";
import { CATEGORIES } from "@/data/categories";
import { FARMERS } from "@/data/farmers";
import { DEMAND_FORECASTS } from "@/data/aiInsights";
import ProductCard from "@/components/ProductCard";
import FarmerCard from "@/components/FarmerCard";
import SectionHeading from "@/components/SectionHeading";
import IndiaMap from "@/components/IndiaMap";

export default function Home() {
  const { products, farmers } = useStore();
  const trending = products.slice(0, 10);
  const freshFromFarms = products.slice(5, 13);
  const recommended = products.slice(10, 18);
  const nearbyFarmers = farmers.slice(0, 6);

  const trustIndicators = [
    { icon: BadgeCheck, title: "Verified Farmers", desc: "Every farmer is verified" },
    { icon: ShieldCheck, title: "Verified Products", desc: "Quality assured produce" },
    { icon: TrendingUp, title: "Better Prices", desc: "Direct from farm to you" },
    { icon: Leaf, title: "Transparent Marketplace", desc: "Full traceability" },
  ];

  const stats = [
    { icon: Users, label: "Verified Farmers", value: "12,000+" },
    { icon: Package, label: "Products Listed", value: "45,000+" },
    { icon: Store, label: "Buyers Connected", value: "8,500+" },
    { icon: Truck, label: "Deliveries Made", value: "32,000+" },
  ];

  const steps = [
    { num: 1, title: "Find Fresh Produce", desc: "Browse products from verified farmers across India", icon: Search },
    { num: 2, title: "Connect Directly With Farmers", desc: "No middlemen - talk to the farmer directly", icon: Users },
    { num: 3, title: "Secure Digital Payment", desc: "Pay safely via UPI, Card or Digital Wallet", icon: ShieldCheck },
    { num: 4, title: "Fast & Transparent Delivery", desc: "Track your order from farm to your doorstep", icon: Truck },
  ];

  const farmerSteps = [
    "Register", "List Produce", "Get AI Demand Insights", "Connect With Buyers",
    "Delivery", "Receive Payment",
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-green-50 via-white to-amber-50 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-green-300 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-72 h-72 bg-amber-300 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div className="animate-slide-up">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
                Fresh From Indian Farms. <span className="text-green-600">Directly To You.</span>
              </h1>
              <p className="mt-4 text-base sm:text-lg text-gray-600 max-w-lg">
                Buy fresh agricultural produce directly from verified farmers and FPOs across India. Better prices for farmers, fresher produce for you.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link
                  to="/products"
                  className="flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl shadow-md transition-all hover:scale-105"
                >
                  <ShoppingCart className="w-5 h-5" />
                  Shop Fresh Produce
                </Link>
                <Link
                  to="/farmer/register"
                  className="flex items-center gap-2 px-6 py-3 bg-white hover:bg-gray-50 text-green-700 font-semibold rounded-xl border-2 border-green-600 transition-all hover:scale-105"
                >
                  <Sprout className="w-5 h-5" />
                  Become a Farmer Seller
                </Link>
              </div>
              <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3">
                {trustIndicators.map((item) => (
                  <div key={item.title} className="flex flex-col items-start gap-1">
                    <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                      <item.icon className="w-5 h-5 text-green-700" />
                    </div>
                    <div className="text-xs font-semibold text-gray-800">{item.title}</div>
                    <div className="text-[10px] text-gray-500">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative hidden lg:block">
              <div className="grid grid-cols-2 gap-3">
                <img
                  src="https://images.pexels.com/photos/3173586/pexels-photo-3173586.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                  alt="Fresh tomatoes"
                  className="rounded-2xl shadow-lg w-full h-48 object-cover"
                />
                <img
                  src="https://images.pexels.com/photos/25541362/pexels-photo-25541362.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                  alt="Fresh onions"
                  className="rounded-2xl shadow-lg w-full h-48 object-cover mt-6"
                />
                <img
                  src="https://images.pexels.com/photos/7543169/pexels-photo-7543169.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                  alt="Fresh mangoes"
                  className="rounded-2xl shadow-lg w-full h-48 object-cover -mt-4"
                />
                <img
                  src="https://images.pexels.com/photos/7421207/pexels-photo-7421207.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                  alt="Basmati rice"
                  className="rounded-2xl shadow-lg w-full h-48 object-cover mt-2"
                />
              </div>
              <div className="absolute -bottom-4 -left-4 bg-white rounded-xl shadow-xl p-3 flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                  <Truck className="w-5 h-5 text-green-700" />
                </div>
                <div>
                  <div className="text-xs font-bold text-gray-900">Farm to Doorstep</div>
                  <div className="text-[10px] text-gray-500">24-48 hour delivery</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <SectionHeading title="Popular Categories" subtitle="Browse by product type" viewAllLink="/products" />
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-3">
          {CATEGORIES.map((cat) => (
            <Link
              key={cat.id}
              to={`/products?category=${cat.id}`}
              className="group bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-lg hover:border-green-300 transition-all"
            >
              <div className="aspect-square overflow-hidden bg-gray-100">
                <img
                  src={cat.image}
                  alt={cat.name}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="p-2 text-center">
                <div className="text-xs sm:text-sm font-semibold text-gray-800 group-hover:text-green-700 transition-colors">
                  {cat.name}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Fresh From Farms */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SectionHeading title="Fresh From Farms" subtitle="Just harvested produce" viewAllLink="/products" />
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
          {freshFromFarms.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Trending Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SectionHeading title="Trending Products" subtitle="Most viewed this week" viewAllLink="/products" />
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
          {trending.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Recommended For You */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SectionHeading title="Recommended For You" subtitle="Based on trending produce" viewAllLink="/products" />
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
          {recommended.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Nearby Farmers */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SectionHeading title="Nearby Farmers" subtitle="Verified farmers near you" viewAllLink="/farmers" />
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {nearbyFarmers.map((f) => (
            <FarmerCard key={f.id} farmer={f} />
          ))}
        </div>
      </section>

      {/* Farmers Across India - Interactive Map */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SectionHeading title="Farmers Across India" subtitle="Find verified farmers on the interactive map" viewAllLink="/find-farmers" />
        <IndiaMap height="450px" />
      </section>

      {/* AI Demand Insights Preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SectionHeading title="AI Demand Insights" subtitle="Smart market predictions powered by AI" viewAllLink="/ai-insights" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {DEMAND_FORECASTS.slice(0, 6).map((d) => (
            <div key={d.product} className="bg-white rounded-2xl border border-gray-200 p-4 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold text-gray-900">{d.product}</h3>
                <span className={`px-2 py-0.5 text-xs font-medium rounded-md ${
                  d.demandStatus === "High" ? "bg-red-50 text-red-600" :
                  d.demandStatus === "Moderate" ? "bg-amber-50 text-amber-600" :
                  "bg-green-50 text-green-600"
                }`}>
                  {d.demandStatus}
                </span>
              </div>
              <div className="space-y-1 text-sm text-gray-600">
                <div className="flex justify-between"><span>Expected Demand:</span><span className="font-medium">{d.expectedDemand} {d.unit}</span></div>
                <div className="flex justify-between"><span>Available Supply:</span><span className="font-medium">{d.availableSupply} {d.unit}</span></div>
                <div className="flex justify-between"><span>Recommended Price:</span><span className="font-bold text-green-700">₹{d.recommendedPrice}/{d.unit}</span></div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* How FarmConnect Works */}
      <section className="bg-green-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading title="How FarmConnect Works" subtitle="A simple 4-step process for buyers" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {steps.map((step) => (
              <div key={step.num} className="bg-white rounded-2xl p-5 border border-green-100 hover:shadow-md transition-shadow">
                <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center mb-3">
                  <step.icon className="w-6 h-6 text-green-700" />
                </div>
                <div className="text-xs font-bold text-green-600 mb-1">STEP {step.num}</div>
                <h3 className="font-semibold text-gray-900 text-sm">{step.title}</h3>
                <p className="text-xs text-gray-500 mt-1">{step.desc}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 bg-white rounded-2xl p-5 border border-green-100">
            <h3 className="font-semibold text-gray-900 text-sm mb-4">For Farmers - 6 Simple Steps</h3>
            <div className="flex flex-wrap items-center gap-2">
              {farmerSteps.map((step, i) => (
                <div key={step} className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 rounded-lg">
                    <span className="w-5 h-5 rounded-full bg-green-600 text-white text-xs font-bold flex items-center justify-center">{i + 1}</span>
                    <span className="text-xs font-medium text-gray-700">{step}</span>
                  </div>
                  {i < farmerSteps.length - 1 && <ArrowRight className="w-3 h-3 text-gray-300" />}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Statistics */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-gradient-to-br from-green-50 to-white rounded-2xl p-5 border border-green-100 text-center">
              <div className="w-12 h-12 rounded-xl bg-green-600 flex items-center justify-center mx-auto mb-3">
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
              <div className="text-xs text-gray-500 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
