/*
# Create FarmConnect Database Schema

## Overview
Creates the core database tables for the FarmConnect agricultural marketplace:
farmers, products, orders, and order_items. Seeds them with the existing
sample data (32 farmers, 52 products) so the marketplace is populated
immediately. Also creates an orders table for checkout persistence.

## 1. New Tables

### farmers
Stores verified farmer/FPO profiles across all Indian states and UTs.
- `id` text primary key (e.g. "f001")
- `name` text not null — farmer or FPO display name
- `image` text — profile photo URL
- `verified` boolean default true — verification status
- `state` text not null — Indian state/UT
- `city` text not null — city within the state
- `main_crops` text[] — array of crop names
- `products_count` int default 0 — number of active listings
- `distance` int default 0 — distance in km (for display)
- `rating` numeric(2,1) default 5.0 — farmer rating
- `total_sales` bigint default 0 — lifetime sales in INR
- `joined_date` date — when the farmer joined
- `farm_size` text — e.g. "15 acres"
- `fpo_name` text nullable — official FPO name if applicable
- `description` text — farmer bio
- `created_at` timestamptz default now()

### products
Stores agricultural product listings from farmers.
- `id` text primary key (e.g. "p001")
- `name` text not null — product name
- `category` text not null — one of: vegetables, fruits, grains, pulses, spices, oilseeds, millets, organic, other
- `image` text — product photo URL
- `farmer_id` text not null FK → farmers(id) ON DELETE CASCADE
- `farmer_name` text not null — denormalized farmer name for quick display
- `verified` boolean default true — mirrors farmer verification
- `state` text not null — Indian state/UT
- `city` text not null — city
- `grade` text not null — "Grade A" | "Grade B" | "Grade C"
- `available_qty` numeric not null — available stock quantity
- `unit` text not null — "kg" | "g" | "tonne"
- `price_per_unit` numeric not null — price per unit in INR
- `harvest_date` date — when the crop was harvested
- `description` text — product description
- `freshness` text — freshness label for display
- `is_organic` boolean default false — organic flag
- `created_at` timestamptz default now()

### orders
Stores buyer orders placed through checkout.
- `id` text primary key (e.g. "ORD1234567890")
- `buyer_name` text not null
- `buyer_address` text not null
- `buyer_phone` text not null
- `subtotal` numeric not null
- `delivery_charge` numeric not null default 0
- `total` numeric not null
- `status` text not null default 'Order Confirmed'
- `payment_status` text not null default 'Pending'
- `payment_method` text not null
- `order_date` text not null — formatted date string
- `estimated_delivery` text not null
- `created_at` timestamptz default now()

### order_items
Stores individual line items within an order.
- `id` uuid primary key default gen_random_uuid()
- `order_id` text not null FK → orders(id) ON DELETE CASCADE
- `product_id` text — nullable FK → products(id) ON DELETE SET NULL
- `product_name` text not null — denormalized name
- `farmer_name` text not null — denormalized farmer
- `quantity` numeric not null — qty purchased
- `unit` text not null — "kg" | "g" | "tonne"
- `price_per_unit` numeric not null — price at time of order
- `image` text — product image URL
- `created_at` timestamptz default now()

## 2. Indexes
- `products_farmer_id_idx` — fast farmer→products lookup
- `products_category_idx` — category filtering
- `products_state_idx` — state filtering
- `products_state_city_idx` — state+city compound filter
- `orders_created_at_idx` — newest-first ordering
- `order_items_order_id_idx` — order→items lookup

## 3. Security (RLS)
All tables use `TO anon, authenticated` with `USING (true)` / `WITH CHECK (true)`
because FarmConnect is a single-tenant public marketplace with no sign-in screen.
The anon-key frontend must be able to read and write all data.

## 4. Important Notes
- No `user_id` columns or `auth.users` references — no auth in this app.
- Products cascade-delete when a farmer is deleted.
- Order items cascade-delete when an order is deleted.
- Order items keep their denormalized product/farmer names even if the
  product is later removed (product_id becomes NULL via ON DELETE SET NULL).
*/

-- =========================================================
-- FARMERS TABLE
-- =========================================================
CREATE TABLE IF NOT EXISTS farmers (
  id text PRIMARY KEY,
  name text NOT NULL,
  image text,
  verified boolean NOT NULL DEFAULT true,
  state text NOT NULL,
  city text NOT NULL,
  main_crops text[] NOT NULL DEFAULT '{}',
  products_count int NOT NULL DEFAULT 0,
  distance int NOT NULL DEFAULT 0,
  rating numeric(2,1) NOT NULL DEFAULT 5.0,
  total_sales bigint NOT NULL DEFAULT 0,
  joined_date date,
  farm_size text,
  fpo_name text,
  description text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE farmers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_farmers" ON farmers;
CREATE POLICY "anon_select_farmers" ON farmers FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_farmers" ON farmers;
CREATE POLICY "anon_insert_farmers" ON farmers FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_farmers" ON farmers;
CREATE POLICY "anon_update_farmers" ON farmers FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_farmers" ON farmers;
CREATE POLICY "anon_delete_farmers" ON farmers FOR DELETE
  TO anon, authenticated USING (true);

-- =========================================================
-- PRODUCTS TABLE
-- =========================================================
CREATE TABLE IF NOT EXISTS products (
  id text PRIMARY KEY,
  name text NOT NULL,
  category text NOT NULL,
  image text,
  farmer_id text NOT NULL REFERENCES farmers(id) ON DELETE CASCADE,
  farmer_name text NOT NULL,
  verified boolean NOT NULL DEFAULT true,
  state text NOT NULL,
  city text NOT NULL,
  grade text NOT NULL,
  available_qty numeric NOT NULL,
  unit text NOT NULL,
  price_per_unit numeric NOT NULL,
  harvest_date date,
  description text,
  freshness text,
  is_organic boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_products" ON products;
CREATE POLICY "anon_select_products" ON products FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_products" ON products;
CREATE POLICY "anon_insert_products" ON products FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_products" ON products;
CREATE POLICY "anon_update_products" ON products FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_products" ON products;
CREATE POLICY "anon_delete_products" ON products FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS products_farmer_id_idx ON products(farmer_id);
CREATE INDEX IF NOT EXISTS products_category_idx ON products(category);
CREATE INDEX IF NOT EXISTS products_state_idx ON products(state);
CREATE INDEX IF NOT EXISTS products_state_city_idx ON products(state, city);

-- =========================================================
-- ORDERS TABLE
-- =========================================================
CREATE TABLE IF NOT EXISTS orders (
  id text PRIMARY KEY,
  buyer_name text NOT NULL,
  buyer_address text NOT NULL,
  buyer_phone text NOT NULL,
  subtotal numeric NOT NULL,
  delivery_charge numeric NOT NULL DEFAULT 0,
  total numeric NOT NULL,
  status text NOT NULL DEFAULT 'Order Confirmed',
  payment_status text NOT NULL DEFAULT 'Pending',
  payment_method text NOT NULL,
  order_date text NOT NULL,
  estimated_delivery text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_orders" ON orders;
CREATE POLICY "anon_select_orders" ON orders FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_orders" ON orders;
CREATE POLICY "anon_insert_orders" ON orders FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_orders" ON orders;
CREATE POLICY "anon_update_orders" ON orders FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_orders" ON orders;
CREATE POLICY "anon_delete_orders" ON orders FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS orders_created_at_idx ON orders(created_at DESC);

-- =========================================================
-- ORDER_ITEMS TABLE
-- =========================================================
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id text NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id text REFERENCES products(id) ON DELETE SET NULL,
  product_name text NOT NULL,
  farmer_name text NOT NULL,
  quantity numeric NOT NULL,
  unit text NOT NULL,
  price_per_unit numeric NOT NULL,
  image text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_order_items" ON order_items;
CREATE POLICY "anon_select_order_items" ON order_items FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_order_items" ON order_items;
CREATE POLICY "anon_insert_order_items" ON order_items FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_order_items" ON order_items;
CREATE POLICY "anon_update_order_items" ON order_items FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_order_items" ON order_items;
CREATE POLICY "anon_delete_order_items" ON order_items FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS order_items_order_id_idx ON order_items(order_id);
